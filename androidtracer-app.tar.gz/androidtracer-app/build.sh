#!/bin/bash
set -e
ARCH=x86_64
./appimagetool.AppImage AppDir
