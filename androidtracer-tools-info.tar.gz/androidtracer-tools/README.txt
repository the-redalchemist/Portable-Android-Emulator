
# AndroidTracer Tools

This folder is meant to contain real binaries for:

- `adb` (from Android SDK Platform-Tools)
  → https://developer.android.com/studio/releases/platform-tools

- `qemu-system-x86_64` (from your system or static build)

- `tshark` (Wireshark CLI)
  → https://www.wireshark.org/download.html (look for static builds or build yourself)

Place them into the `AppDir/usr/bin/` folder of your AppImage structure.

Example:

    cp adb AppDir/usr/bin/
    cp qemu-system-x86_64 AppDir/usr/bin/
    cp tshark AppDir/usr/bin/

Make sure each is executable:

    chmod +x AppDir/usr/bin/*
